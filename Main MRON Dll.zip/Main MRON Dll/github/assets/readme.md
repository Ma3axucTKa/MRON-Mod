This folder is used for files shown on the Readme section of the GitHub repository.
It will not be directly used in the Donetsk Project.