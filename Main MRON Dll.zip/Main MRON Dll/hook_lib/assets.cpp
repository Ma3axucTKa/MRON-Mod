#include "assets.h"


void test() {
	sizeof(VehicleDef);
}