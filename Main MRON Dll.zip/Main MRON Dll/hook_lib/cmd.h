#pragma once
#include "Main.hpp"

void Cmd_Exec_Internal(bool isSuperUser);