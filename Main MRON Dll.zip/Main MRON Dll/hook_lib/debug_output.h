#pragma once

inline bool gameInitialized = false;

void debug_output_init(const char* output_file);