#pragma once
#include "Main.hpp"

void SaveInventory();

void LoadInventory();