#pragma once

#pragma comment(lib, "discord-rpc.lib")

void DiscordThread();