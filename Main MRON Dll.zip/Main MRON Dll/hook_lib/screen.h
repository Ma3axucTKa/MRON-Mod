#pragma once
#include "Main.hpp"

void CL_ScreenMP_DrawOverlay_Detour();